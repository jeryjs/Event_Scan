import os
import random
from PIL import Image
import requests
import zipfile
import io

def generate_random_codes(prefix, count, output_file="barcodes.txt"):
    if len(prefix) >= 10:
        raise ValueError("Prefix length must be less than 10 characters")
    
    numbers = set()
    while len(numbers) < count:
        remaining_length = 10 - len(prefix)
        random_number = ''.join(random.choices('0123456789', k=remaining_length))
        unique_code = prefix + random_number
        numbers.add(unique_code)
        
    # with open(output_file, "w") as f:
    #     for c in codes:
    #         f.write(f"{c}\n")
    
    return list(numbers)

def generate_barcodes(codes, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    url = f"https://barcodes.pro/get/generator?b=1&f=png&s=code128&d={'%0A'.join(codes)}&cm=000&sf=6&sy=1&ts=20&th=40"
    response = requests.get(url)
    if response.status_code == 200:
        with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
            zip_ref.extractall(output_dir)
        print(f"Extracted to {output_dir}")
    else:
        print(f"Failed to download barcodes")
        
def attach_barcode(ticket_img, barcode_img, output_path, placement):
    x, y = placement

    if barcode_img.mode != 'RGBA':
        barcode_img = barcode_img.convert('RGBA')
    ticket_img.paste(barcode_img, (x, y), barcode_img.split()[3])
    ticket_img.save(output_path)
    print(output_path)
  
def generate_tickets(ticket_path="./ticket.webp", barcode_dir="./barcodes", output_dir="./tickets"):
    ticket_img = Image.open(ticket_path)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for barcode_file in os.listdir(barcode_dir):
        barcode_path = os.path.join(barcode_dir, barcode_file)
        barcode_img = Image.open(barcode_path).rotate(270, expand=True).resize((100, 550))

        output_path = os.path.join(output_dir, f"ticket_{barcode_file[:-4]}.webp")
        placement = (235, 0)
        
        attach_barcode(ticket_img, barcode_img, output_path, placement)

if __name__ == "__main__":
    # codes = generate_random_codes("FP24", 500)
            
    # generate_barcodes(codes, "./barcodes")
    
    generate_tickets("./ticket_ce.webp", "./barcodes_ce", "./tickets_ce")
    generate_tickets("./ticket_se.webp", "./barcodes_se", "./tickets_se")