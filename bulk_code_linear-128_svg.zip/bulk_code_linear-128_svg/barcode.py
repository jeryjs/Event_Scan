import os
from PIL import Image

def attach_barcode(ticket_img, barcode_img, output_path, placement):
    x, y = placement

    if barcode_img.mode != 'RGBA':
        barcode_img = barcode_img.convert('RGBA')
    ticket_img.paste(barcode_img, (x, y), barcode_img.split()[3])
    ticket_img.save(output_path)
    print("done")

def main():
    ticket_path = "bulk_code_linear-128_svg/ticket.webp"
    barcode_dir = "bulk_code_linear-128_svg/barcodes"
    output_dir = "bulk_code_linear-128_svg/tickets"

    ticket_img = Image.open(ticket_path)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for barcode_file in os.listdir(barcode_dir):
        barcode_path = os.path.join(barcode_dir, barcode_file)
        barcode_img = Image.open(barcode_path).rotate(270, expand=True).resize((100, 550))

        output_path = os.path.join(output_dir, f"ticket_{barcode_file[:-4]}.webp")
        placement = (235, 0)
        
        attach_barcode(ticket_img, barcode_img, output_path, placement)

if __name__ == "__main__":
    main()